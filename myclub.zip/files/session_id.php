<?php 
$session_id = session_id();
?>