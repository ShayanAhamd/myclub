<?php
    $imageUrl = '';
?>