<link rel="stylesheet" href="../css/socialsidebar.css">
<nav class='nabs'>
    <ul>
        <li><a href="#"><i class="fa fa-facebook-f"></i><span>Facebook</span></a></li>
        <li><a href="#"><i class="fa fa-twitter"></i><span>Twitter</span></a></li>
        <li><a href="#"><i class="fa fa-instagram"></i><span>Instagram</span></a></li>
    </ul>
</nav>